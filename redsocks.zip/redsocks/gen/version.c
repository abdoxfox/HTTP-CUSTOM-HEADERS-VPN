/* this file is auto-generated during build */
#include "../version.h"
const char* redsocks_version = 
"redsocks.git/release-0.5-11-g19b822e"
;
